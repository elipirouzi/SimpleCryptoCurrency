document.getElementById('exchangeBtn').addEventListener('click',function(){
    const crpAMount = document.getElementById('cryptoAmount').value
    const crpType = document.getElementById('cryptoAmount').value
    const crnyType = document.getElementById('currencyType').value
    let endResult = document.getElementById('result')
    
    if(crpAMount <= 0){
        alert('please, Enter valid number!')
    }
    fetch('https://api.coinconvert.net/convert/btc/usd?amount=1')
    .then(res => res.json())
    .then(data =>{
        endResult.value = (crpAMount*(data.BTC)*(data.USD)).toFixed(2)
    })
})


const _showData = document.getElementById("showData");
let num = 8
let page = 1
let load = () => {
    fetch(
            "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=" + num + "&page=" + page + "&sparkline=false")
        .then((res) => {
            if (res.ok) {
                return res.json();
            }
            Promise.reject(err);
        })
        .then((data) => {
            data.map(function (val) {
                const _article = document.createElement("article");
                _article.innerHTML = `
                <figure>
                    <img src=${val.image} alt="">
                    <figcaption>${val.name}</figcaption>
                </figure>
                <div>
                    <h6>${val.current_price}  ${val.symbol}</h6>
                </div>
                <div>${val.price_change_percentage_24h}</div>
                <div id="chart-${val.id}">${Highcharts}</div>
            `;
                _showData.appendChild(_article);

                Highcharts.chart(`chart-${val.id}`, {
                    exporting: {
                        enabled: false,
                    },
                    credits: {
                        enabled: false
                    },
                    chart: {
                        height: 150
                    },
                    title: {
                        text: null,
                    },
                    yAxis: {
                        data: [0, 5, 10],
                        title: {
                            text: null,
                        },
                        labels: {
                            style: {
                                color: '#64646446'
                            }
                        }
                    },
                    xAxis: {
                        category: [val.low_24h, val.current_price, val.high_24h],
                        accessibility: {
                            rangeDescription: 'Range: 0 to 60',
                        },
                        title: {
                            text: null,
                            enabled: false
                        },
                        labels: {
                            enabled: false,
                            // lineWidth: 0,
                        },
                        gridLineWidth: 0,
                        lineWidth: 1,
                        tickWidth: 0,
                        lineColor: '#64646415',
                    },
                    stroke: {
                        linejoin: "round",
                        visibility: "visible",
                        stroke: "rgba(104, 216, 39, 0.767)",
                        width: "25",
                    },
                    labels: {
                        enabled: false,
                    },
                    legend: {
                        enabled: false
                    },
                    plotOptions: {
                        series: {
                            marker: {
                                enabled: false
                            }
                        }
                    },
                    series: [{
                        data: [val.low_24h, val.current_price, val.high_24h],
                        name: 'price',
                        color: '#ffd500'
                    }, ]
                });
            });
            page++
        })
        .catch((err) => console.error(err));
}
load()
setInterval(load,100000)
